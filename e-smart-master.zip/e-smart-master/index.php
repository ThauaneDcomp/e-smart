<!DOCTYPE html>
<html lang="pt-br">
    <head>
        <meta charset="utf-8">
        <meta name="author" content="Weslan Rezende Alves">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <link rel="shortcut icon" href="imagem/icon.png" type="image/x-icon"/>
    </head>
    <body>
        <h3>TESTE</h3>
    </body>
</html>