# e-smart
## https://e-smart-weslan.c9users.io/
Database translator for JSON or sending to bases ORION - FIWARE
